#include <stdio.h>
#include <stdlib.h>
#define size 30

typedef struct node
{
    int num;
    struct node *next;
} node;

node *sort(node *start)
{

    node *first, *nextNode, tempNode;
    first = start;
    if (start == NULL)
    {
        return start;
    }
    if (start->next == NULL)
    {
        return start;
    }

    while (first->next != NULL)
    {
        nextNode = first->next;
        while (nextNode != NULL)
        {
            if (first->num > nextNode->num)
            {
                tempNode = *first;
                *first = *nextNode;
                *nextNode = tempNode;
                tempNode.next = first->next;
                first->next = nextNode->next;
                nextNode->next = tempNode.next;
            }
            nextNode = nextNode->next;
        }
        first = first->next;
    }

    return start;
}

node *insertNodeSorted(node *start, int max_val)
{
    int item;
    node *newNode;
    item = rand() % max_val;

    newNode = (node *)malloc(sizeof(node));
    if (newNode == NULL)
    {
        exit(-1);
        printf("Malloc failed.\n");
    }
    newNode->num = item;
    newNode->next = start;
    start = newNode;

    start = sort(start);

    return start;
}

void printList(node *start)
{
    while (start != NULL)
    {
        printf("The number is %i\n", start->num);
        start = start->next;
    }
}

void deleteList(node *start)
{
    if (start->next != NULL)
        deleteList(start->next);
    free(start);
}

int main(int argc, char **argv)
{

    int seed, listSize, max_val, i;
    node *first = NULL;

    if (argc != 4)
    {
        printf("Arguments error. Please check the input.\n");
        exit(-1);
    }

    seed = atoi(argv[1]);
    listSize = atoi(argv[2]);
    max_val = atoi(argv[3]);

    if (seed < 0 || listSize < 0 || max_val < 0)
    {
        printf("Values cannot be negative.\n");
        exit(-1);
    }

    srand(seed);

    for (i = 0; i < listSize; i++)
    {
        first = insertNodeSorted(first, max_val);
    }

    printList(first);
    deleteList(first);

    return 0;
}